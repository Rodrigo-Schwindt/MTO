<?php

namespace App\Livewire\Vistas\Equipamiento;

use App\Models\EquipmentPage;
use App\Models\EquipmentProduct;
use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('layouts.public2')]
class EquipmentPublic extends Component
{
    public function render()
    {
        return view('livewire.vistas.equipamiento.equipamiento-public', [
            'pageData' => EquipmentPage::first(),
            'products' => EquipmentProduct::with(['mainImage', 'images'])
                ->visible()
                ->ordered()
                ->get(),
        ]);
    }
}
