<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement('ALTER TABLE contact MODIFY frame_adm TEXT NULL');
    }

    public function down(): void
    {
        DB::statement('ALTER TABLE contact MODIFY frame_adm VARCHAR(255) NULL');
    }
};
