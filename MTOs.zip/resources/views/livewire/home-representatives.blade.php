@section('page-title', 'Inicio / Representantes')

@extends('layouts.admin')

@section('content')
<div class="max-w-4xl space-y-8 animate-fadeIn bg-white border border-slate-200 rounded-md shadow-sm p-8">
    <div class="flex items-center justify-between">
        <div>
            <h2 class="text-2xl font-semibold text-slate-900">Representantes</h2>
            <p class="text-sm text-slate-500 mt-1">Se muestran en la home debajo del slider.</p>
        </div>
    </div>

    @if(session('success'))
        <div class="px-4 py-3 rounded-md bg-green-50 border border-green-200 text-green-700 text-sm">
            {{ session('success') }}
        </div>
    @endif

    @if($errors->any())
        <div class="px-4 py-3 rounded-md bg-red-50 border border-red-200 text-red-700 text-sm">
            Revisá los campos marcados.
        </div>
    @endif

    <form action="{{ route('home.representatives.save') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
        @csrf

        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Título</label>
            <input type="text"
                   name="title"
                   value="{{ old('title', $representatives?->title) }}"
                   class="w-full border border-slate-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#52A028]">
            @error('title') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            @foreach([1, 2] as $index)
                @php $field = "logo_{$index}"; @endphp
                <div class="border border-slate-200 rounded-md p-4">
                    <label class="block text-sm font-medium text-slate-700 mb-3">Logo {{ $index }}</label>

                    <div class="h-28 rounded-md border border-slate-200 bg-slate-50 flex items-center justify-center mb-4">
                        @if($representatives?->$field)
                            <img src="{{ Storage::url($representatives->$field) }}" alt="Logo {{ $index }}" class="max-h-20 max-w-[220px] object-contain">
                        @else
                            <span class="text-sm text-slate-400">Sin logo</span>
                        @endif
                    </div>

                    <input type="file"
                           name="{{ $field }}"
                           accept=".jpg,.jpeg,.png,.webp,.gif,.svg"
                           class="w-full border border-slate-300 rounded-md px-3 py-2 text-sm">
                    @error($field) <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror

                    @if($representatives?->$field)
                        <label class="inline-flex items-center gap-2 mt-3">
                            <input type="checkbox" name="remove_{{ $field }}" value="1">
                            <span class="text-sm text-slate-700">Eliminar logo actual</span>
                        </label>
                    @endif
                </div>
            @endforeach
        </div>

        <div class="flex justify-end gap-3 pt-2">
            <a href="{{ route('sliders.index') }}" class="px-5 py-2.5 rounded-md border border-slate-300 text-slate-700 hover:bg-slate-50">
                Cancelar
            </a>
            <button class="px-5 py-2.5 rounded-md bg-[#52A028] text-white hover:bg-[#3d7a1e]">
                Guardar
            </button>
        </div>
    </form>
</div>
@endsection
