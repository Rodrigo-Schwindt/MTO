<?php

namespace App\Http\Controllers;

use App\Models\HomeRepresentative;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class HomeRepresentativesController extends Controller
{
    public function index()
    {
        $representatives = HomeRepresentative::first();

        return view('livewire.home-representatives', [
            'representatives' => $representatives,
        ]);
    }

    public function save(Request $request)
    {
        $validated = $request->validate([
            'title' => 'nullable|string|max:255',
            'logo_1' => 'nullable|mimes:jpg,jpeg,png,webp,gif,svg|max:4096',
            'logo_2' => 'nullable|mimes:jpg,jpeg,png,webp,gif,svg|max:4096',
        ]);

        $representatives = HomeRepresentative::first() ?? new HomeRepresentative();
        $representatives->title = $validated['title'] ?? null;

        foreach ([1, 2] as $index) {
            $field = "logo_{$index}";

            if ($request->hasFile($field)) {
                if ($representatives->$field) {
                    Storage::disk('public')->delete($representatives->$field);
                }

                $representatives->$field = $request->file($field)->store('home-representatives', 'public');
            }

            if ($request->has("remove_{$field}")) {
                if ($representatives->$field) {
                    Storage::disk('public')->delete($representatives->$field);
                }

                $representatives->$field = null;
            }
        }

        $representatives->save();

        return redirect()
            ->route('home.representatives.index')
            ->with('success', 'Representantes guardados correctamente');
    }
}
