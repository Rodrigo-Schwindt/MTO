<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PresupuestoPage extends Model
{
    use HasFactory;

    protected $fillable = [
        'image_banner',
    ];
}
