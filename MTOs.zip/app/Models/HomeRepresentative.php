<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HomeRepresentative extends Model
{
    protected $fillable = [
        'title',
        'logo_1',
        'logo_2',
    ];
}
