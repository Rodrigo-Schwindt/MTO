<?php

namespace App\Livewire\Vistas\Equipamiento;

use App\Models\EquipmentProduct;
use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('layouts.public')]
class EquipmentDetail extends Component
{
    public string $slug;

    public function mount(string $slug): void
    {
        $this->slug = $slug;
    }

    public function render()
    {
        $product = EquipmentProduct::with(['images', 'relatedProducts.mainImage', 'relatedProducts.images'])
            ->visible()
            ->where('slug', $this->slug)
            ->firstOrFail();

        return view('livewire.vistas.equipamiento.equipamiento-detalle', [
            'product' => $product,
        ]);
    }
}
